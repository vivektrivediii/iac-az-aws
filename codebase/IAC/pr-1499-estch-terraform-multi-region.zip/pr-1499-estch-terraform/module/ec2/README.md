
# Terraform EC2 

## Overview

This Terraform module facilitates the creation of Amazon Elastic Compute Cloud (EC2) instances within an AWS environment. EC2 instances serve as virtual servers in the cloud, offering scalable computing capacity. They are fundamental building blocks for various cloud-based applications and services.



## Table of Contents

- [Prerequisites](#prerequisites)
- [Inputs](#inputs)
- [Module Usage](#module-usage)

## Prerequisites

Before using this Terraform module, ensure you have the following prerequisites installed on your machine:

- [Terraform](https://www.terraform.io/downloads.html)
- [AWS CLI](https://aws.amazon.com/cli/)


## Inputs

| Name                           | Type           | Default                    | Mandatory | Description                                                      |
|--------------------------------|----------------|----------------------------|-----------|------------------------------------------------------------------|
| instance_type               | string         | "t4g.medium"                          | No       | Type of the instance                                     |
| key_pair_name               | string         | ""                          | No       | Name of the key pair                                     |
| iam_instance_profile.create_new_instance_profile          | bool         | -                        | Yes       | To create new instance profile or not       |
| iam_instance_profile.custom_iam_instance_profile_name          | string         | -                        | Yes       | Custom iam instance profile name       |
| iam_instance_profile.iam_role_name          | string         | -                        | Yes       | IAM role name for custom instance profile       |
| iam_instance_profile.create_inline_policy          | bool         | -                        | Yes       | To create inline policy or not       |
| iam_instance_profile.inline_iam_policy_name          | string         | -                        | Yes       | Inline policy name       |
| iam_instance_profile.inline_iam_policy_description          | string         | -                        | Yes       | Inline policy description       |
| iam_instance_profile.inline_policy_actions          | list(string)         | -                        | Yes       | Inline policy actions       |
| iam_instance_profile.inline_policy_resource          | string         | -                        | Yes       | Inline policy resource       |
| iam_instance_profile.attach_managed_policy          | bool         | -                        | Yes       | To attach managed policy or not     |
| iam_instance_profile.managed_policy_arns          | list(string)         | -                        | Yes       | Managed policy arns     |
| iam_instance_profile.use_existing_instance_profile          | bool         | -                        | Yes       | To use existing instance profile     |
| iam_instance_profile.existing_instance_profile_name          | string         | -                        | Yes       | Existing instance profile name     |
| subnet_id                     | string   |                          | Yes       | Subnet Id                                              |
| vpc_security_group_ids             | list(string)         |                           | Yes       | List of security group Ids |
| root_block_device_details.volume_type              | string         |                         | Yes       | Volume type of root block device                           |                                                  |
| root_block_device_details.volume_size              | string         |                         | Yes       | Volume size of root block device                           |                                                  |
| root_block_device_details.delete_on_termination              | bool         |                         | Yes       | delete on termination of root block device                           |                                                  |
| spot_instance_details.max_price         | string         | -                          | No       | Spot instance max price                           |
| user_data_script              | string         | ""                        | No       | UserData script for the instance                          |                                                  |
| tags         | object         | { Environment = "environment-name" Project = "project-name" }                          | No       | Tags for EC2 instance specifying Environment & Project                                   |
| extra_tags               | map(string)         | {}                          | No       | Additional tags for the instance                               |
| number_of_instances               | number         | 1                          | No       | Number of instances to create                               |


## Module Usage

```hcl
module "ec2_instances" {
  source = "../"

  for_each = local.ec2_instances

  instance_type = each.value.instance_type

  key_pair_name = each.value.key_pair_name

  iam_instance_profile = each.value.iam_instance_profile

  subnet_id              = each.value.subnet_id
  vpc_security_group_ids = each.value.vpc_security_group_ids

  root_block_device_details = each.value.root_block_device

  spot_instance_details = each.value.spot_instance_details

  user_data_script = each.value.user_data_script

  tags       = each.value.tags
  extra_tags = each.value.extra_tags

  number_of_instances = each.value.number_of_instances
}

```

