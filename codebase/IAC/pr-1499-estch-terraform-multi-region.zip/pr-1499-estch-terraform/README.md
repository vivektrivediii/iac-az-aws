# ESTech Terraform AWS Infrastructure

This repository contains Terraform configurations for deploying a comprehensive AWS infrastructure for the ESTech project, including EKS cluster, networking, load balancing, and container orchestration with ARM64 support.

## 🏗️ Architecture Overview

The infrastructure consists of:

- **VPC and Networking**: Custom VPC with public/private subnets across multiple AZs
- **EKS Cluster**: Kubernetes cluster with ARM64 node support
- **Karpenter**: Automatic node provisioning for cost optimization
- **Application Load Balancer**: With AWS Load Balancer Controller
- **Container Services**: Multiple applications with auto-scaling
- **Security**: Security groups, ACM certificates, and IAM roles
- **Monitoring**: Redis cluster for caching and session management

## 📁 Project Structure

```
├── infrastructure/          # Main infrastructure deployment
│   ├── main.tf             # Root module configuration
│   ├── variables.tf        # Input variables
│   ├── terraform.tfvars    # Variable values
│   ├── providers.tf        # Provider configurations
│   └── backend.tf          # Terraform state backend
├── kubernetes/             # Standalone Kubernetes resources
│   ├── main.tf            # Karpenter deployment
│   ├── providers.tf       # K8s/Helm providers with data sources
│   ├── variables.tf       # Cluster connection variables
│   └── data.tf           # EKS cluster data sources
└── module/                # Reusable Terraform modules
    ├── networking/        # VPC, subnets, routing
    ├── eks-cluster/       # EKS cluster setup
    ├── eks-node-group/    # Managed node groups
    ├── eks-services/      # Application deployments
    ├── karpenter/         # Karpenter node provisioning
    ├── alb-controller/    # AWS Load Balancer Controller
    ├── security-group/    # Security group management
    ├── acm/              # SSL certificate management
    ├── redis/            # ElastiCache Redis cluster
    └── ecr/              # Container registry
```

## 🚀 Quick Start

### Prerequisites

1. **AWS CLI** configured with appropriate permissions
2. **Terraform** v1.0+ installed
3. **kubectl** for Kubernetes management
4. **Docker** for container management

### AWS Permissions Required

Ensure your AWS credentials have permissions for:
- EC2, VPC, and networking resources
- EKS cluster and node group management
- IAM role and policy management
- ElastiCache, ECR, and Route53 (if using custom domains)
- Application Load Balancer and Target Groups

### 1. Deploy Infrastructure

```bash
# Clone the repository
git clone <your-repo-url>
cd pr-1499-estch-terraform

# Navigate to infrastructure directory
cd infrastructure

# Copy and customize the terraform.tfvars file
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your specific values

# Initialize Terraform
terraform init

# Review the deployment plan
terraform plan

# Deploy the infrastructure
terraform apply
```

### 2. Connect to EKS Cluster

```bash
# Update kubeconfig (replace with your cluster name and region)
aws eks update-kubeconfig --region us-west-2 --name Your-EKS-Cluster

# Verify connection
kubectl get nodes
```

### 3. Deploy Kubernetes Resources (Optional)

If you want to deploy additional Kubernetes resources separately:

```bash
# Navigate to kubernetes directory
cd ../kubernetes

# Initialize and apply
terraform init
terraform apply
```

## ⚙️ Configuration

### Main Configuration Files

Before deploying, you'll need to create and customize your `terraform.tfvars` file with your specific infrastructure settings.

## 🔧 Advanced Features

### Karpenter Configuration

- **ARM64 Only**: Configured to provision ARM64 instances exclusively
- **Instance Families**: m6g, c6g, r6g (Graviton2/3)
- **Automatic Scaling**: Based on pending pods and resource requirements
- **Cost Optimization**: Spot instance support for non-critical workloads

### Load Balancer Configuration

- **Internet-facing ALB**: Publicly accessible applications
- **Host-based Routing**: Multiple services on single ALB
- **SSL/TLS**: Automatic certificate management with ACM
- **Health Checks**: Configurable health check parameters

### Security Features

- **Security Groups**: Granular network access control
- **IAM Roles**: Least privilege access for services
- **Network Policies**: Kubernetes network segmentation
- **Private Subnets**: Application workloads in private networks

## 📊 Monitoring and Observability

### Redis Cluster

- **ElastiCache Redis**: Session management and caching
- **Multi-AZ**: High availability configuration
- **Security**: VPC-only access with security groups

### Application Metrics

- **HPA Metrics**: CPU and memory-based scaling
- **Prometheus-ready**: Metrics endpoints exposed
- **Health Endpoints**: Application health monitoring

## 🔄 Scaling and Updates

### Horizontal Scaling

```yaml
HPA Configuration:
- Min Replicas: 2
- Max Replicas: 10
- CPU Target: 70%
- Memory Target: 80%
```

### Vertical Scaling

Karpenter automatically provisions larger instances when needed based on resource requests.

### Rolling Updates

Kubernetes deployments configured for zero-downtime updates:

```yaml
Strategy:
- Type: RollingUpdate
- Max Unavailable: 25%
- Max Surge: 25%
```

## 🚨 Troubleshooting

### Common Issues

1. **Provider Authentication Errors**
   ```bash
   # Ensure AWS credentials are configured
   aws sts get-caller-identity
   
   # Update kubeconfig if needed
   aws eks update-kubeconfig --region us-west-2 --name Your-EKS-Cluster
   ```

2. **Karpenter Node Provisioning Issues**
   ```bash
   # Check Karpenter logs
   kubectl logs -n karpenter -l app.kubernetes.io/name=karpenter
   
   # Verify NodePool and NodeClass
   kubectl get nodepool,nodeclass
   ```

3. **Load Balancer Issues**
   ```bash
   # Check ALB Controller logs
   kubectl logs -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller
   
   # Verify ingress status
   kubectl get ingress -A
   ```

### Useful Commands

```bash
# Check cluster status
kubectl cluster-info

# View all resources
kubectl get all -A

# Check node labels and taints
kubectl describe nodes

# Monitor pod scheduling
kubectl get events --sort-by=.metadata.creationTimestamp

# Check Karpenter provisioning
kubectl logs -n karpenter -l app.kubernetes.io/name=karpenter -f
```

## 🔐 Security Considerations

### Network Security

- Private subnets for application workloads
- NAT Gateway for outbound internet access
- Security groups with minimal required access
- VPC endpoints for AWS services (optional)

### Access Control

- IAM roles with least privilege principles
- Kubernetes RBAC for service accounts
- Pod security policies/standards

### Data Protection

- Encryption at rest for EBS volumes
- In-transit encryption for ALB
- Redis encryption (configurable)

## 📝 Maintenance

### Regular Tasks

1. **Update Terraform modules** to latest versions
2. **Patch EKS cluster** and node groups
3. **Review and rotate** IAM credentials
4. **Monitor costs** and optimize instance usage
5. **Update container images** for security patches

### Backup Strategy

- Terraform state stored in S3 backend
- EKS cluster configuration backed up
- Application data backup strategy (application-specific)

## 🆘 Support

### Documentation

- [AWS EKS Documentation](https://docs.aws.amazon.com/eks/)
- [Karpenter Documentation](https://karpenter.sh/)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)

### Logs and Debugging

- CloudWatch Logs for EKS control plane
- Karpenter logs in karpenter namespace
- Application logs via kubectl logs
- ALB access logs (configurable)

---

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

---

**Note**: This infrastructure is designed for development and testing environments. For production deployments, additional security hardening, monitoring, and backup strategies should be implemented.
